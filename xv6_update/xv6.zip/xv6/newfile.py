print "a" * 35 * 1024
